Topdirs.dir_directory "+camlp5";;
Topdirs.dir_load Format.std_formatter "camlp5o.cma";;

type dummy_interactive = START_INTERACTIVE | END_INTERACTIVE;;

#use "Quotexpander.ml";;

Gc.set { (Gc.get()) with Gc.stack_limit = 16777216 };; (* Up the stack size  *)
Format.set_margin 72;;                                 (* Reduce margins     *)

#load "nums.cma";;
open Num;;
open Format;;
let print_num n = print_string(string_of_num n);;      (* Avoid range limit  *)

#install_printer print_num;;                           (* when printing nums *)

#use "lib.ml";;
#use "intro.ml";;
#use "formulas.ml";;
#use "prop.ml";;
#use "defcnf.ml";;
#use "dp.ml";;
#use "fol.ml";;              (* Basic first order logic stuff                *)
#use "skolem.ml";;           (* Prenex and Skolem normal forms               *)
#use "herbrand.ml";;         (* Herbrand theorem and mechanization           *)
#use "unif.ml";;             (* Unification algorithm                        *)
#use "tableaux.ml";;         (* Tableaux                                     *)
#use "resolution.ml";;       (* Resolution                                   *)
#use "prolog.ml";;           (* Horn clauses and Prolog                      *)
