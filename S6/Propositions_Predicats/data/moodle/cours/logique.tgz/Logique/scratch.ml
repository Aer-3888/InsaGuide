if ... then ... else ...
let rec fact n =
  if n = 0 then 1
  else n * (fact (n - 1))

let rec fibo n =
  if n < 2 then n
  else fibo (n - 2) + fibo (n - 1)

let f n nb_steps =
  if n mod 2 = 0 then
    f (n / 2) (nb_steps + 1)
  else
    if n = 1 then nb_steps
    else f (3 * n + 1) (nb_steps + 1)

type tree = Leaf of int | Node of tree * tree 

let f t = 
  match t with
  | Leaf x -> x
  | _ -> 42

let rec sum t = match t with
  | Leaf x -> x
  | Node(x, y) -> sum x + sum y

let rec transform t = match t with
  | Leaf x -> Leaf (2 * x)
  | Node(x, y) -> Node(transform x, transform y)

let rec transform t f = match t with
  | Leaf x -> Leaf (f x)
  | Node(x, y) -> Node(transform x f, transform y f)
    
type 'a tree = Leaf of 'a | Node of 'a tree * 'a tree

type 'a liste = Nil | Cons of 'a * 'a liste 
let rec map f l =
  match l with
  | [] -> []
  | e :: r -> (f e) :: (map f r)

let rec fold f l init =
  match l with
  | [] -> init
  | e :: r -> fold f r (f init e)

filter (fun x -> x > 0) [-1;1;2;-2]
= [1;2]

let rec filter p l =
  match l with
  | [] -> []
  | e :: r -> 
    if p e then e :: (filter p r)
    else filter p r

let compose f g = 









